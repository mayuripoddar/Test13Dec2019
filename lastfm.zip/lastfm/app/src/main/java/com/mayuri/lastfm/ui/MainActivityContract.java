package com.mayuri.lastfm.ui;

import com.mayuri.lastfm.pojo.Album;

import java.util.ArrayList;

public interface MainActivityContract {
    interface View {

        void notifyDataSearch(ArrayList<Album> listOfMessages);

        void clearMessageInput();

        void enableSendButton();

        void disableSendButton();
    }

    interface Presenter {
        void searchText(String message);

        void messageInputTextChanged(String messageInput);
    }
}
