package com.mayuri.lastfm.retrofit;

import com.mayuri.lastfm.pojo.Example;


import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface APIInterface {


    @GET("?")
    Call<Example> getDataFromServer(@Header("accept") String acceptType, @Header("content-type") String contentyType, @Query("method") String strMethod, @Query("album") String strAlbum, @Query("api_key") String strApiKey, @Query("format") String strFormat

    );


}
