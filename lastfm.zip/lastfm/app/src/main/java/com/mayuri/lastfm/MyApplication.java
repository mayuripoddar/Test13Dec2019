package com.mayuri.lastfm;


import android.app.Application;
import android.content.Context;

import com.mayuri.lastfm.di.component.ApplicationComponent;
import com.mayuri.lastfm.di.component.DaggerApplicationComponent;
import com.mayuri.lastfm.di.module.ContextModule;


public class MyApplication extends Application {

    ApplicationComponent applicationComponent;
    public static MyApplication INSTANCE;


    @Override
    public void onCreate() {
        super.onCreate();
        INSTANCE = this;

//        applicationComponent = DaggerApplicationComponent.builder().contextModule(new ContextModule(this)).build();
//        applicationComponent.injectApplication(this);

    }

    public static MyApplication get(Context activity){
        return MyApplication.get(activity.getApplicationContext());
    }
    public static synchronized MyApplication getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new MyApplication();
        }
        return INSTANCE;
    }

    public ApplicationComponent getApplicationComponent() {
        return applicationComponent;
    }
}

