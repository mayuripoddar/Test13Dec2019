package com.mayuri.lastfm.ui;

import com.mayuri.lastfm.pojo.Album;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MainActivityPresenterTest {

    @Mock
    private MainActivityContract.View chatView;
    private MainActivityContract.Presenter chatPresenter;
    @Mock
    private ArrayList<Album> listOfMessages;
    private static final String REGULAR_MESSAGE = "This is regular message";

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        chatPresenter = new MainActivityPresenter(chatView,listOfMessages);
        when(listOfMessages.size()).thenReturn(0);
    }

    @Test
    public void sendMessage_NullInput_NoMessageSent() {
        chatPresenter.searchText(null);

    }

    @Test
    public void sendMessage_EmptyInput_NoMessageSent() {
        chatPresenter.searchText("");

    }

    @Test
    public void sendMessage_NormalInput_MessageSent() {
        chatPresenter.searchText(REGULAR_MESSAGE);
        verify(chatView).clearMessageInput();
    }

    @Test
    public void sendMessage_NormalInputListNotEmpty_MessageSent() {
        when(listOfMessages.size()).thenReturn(5);
        chatPresenter.searchText(REGULAR_MESSAGE);
        verify(chatView).clearMessageInput();
    }

    @Test
    public void messageInputTextChanged_NullString_DisabledSendButton() {
        chatPresenter.messageInputTextChanged(null);
        verify(chatView).disableSendButton();
    }

    @Test
    public void messageInputTextChanged_EmptyString_DisabledSendButton() {
        chatPresenter.messageInputTextChanged("");
        verify(chatView).disableSendButton();
    }

    @Test
    public void messageInputTextChanged_NormalString_EnabledSendButton() {
        chatPresenter.messageInputTextChanged(REGULAR_MESSAGE);
        verify(chatView).enableSendButton();
    }
}
